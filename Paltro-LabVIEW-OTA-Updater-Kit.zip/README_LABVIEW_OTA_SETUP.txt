========================================================================
PALTRO-SD01 | LABVIEW OTA "CHECK + UPDATER" KIT (6 RIGS)
========================================================================

Included in this ZIP:
1. swap_update.bat            - Production-safe self-swapper called by LabVIEW System Exec.vi
2. paltro_updater.py          - Optional Python helper for 1-line check & update
3. publish_labview_release.py - 1-click CLI script to publish new .exe & version.json
4. releases/<RIG>.json        - Live JSON manifests for LabVIEW Unflatten From JSON

Live Manifest URLs (Public HTTPS - No Token Required in LabVIEW):
- Master : https://paltro-sd01.github.io/releases/version.json
- HFRR   : https://paltro-sd01.github.io/releases/HFRR-ADV.json
- BOCLE  : https://paltro-sd01.github.io/releases/BOCLE.json
- IQ-150 : https://paltro-sd01.github.io/releases/LAB-IQ-150.json
- IQ-350 : https://paltro-sd01.github.io/releases/LAB-IQ-350.json
- B2V2   : https://paltro-sd01.github.io/releases/B2V2.json
- AIRJET : https://paltro-sd01.github.io/releases/AIRJET.json
