# 📱 Paltro-SD01 Android App (Native WebView + PWA)

This package builds the native Android `.apk` for the **Paltro-SD01 Engineering & Git Operations Command Center** (`https://paltro-sd01.github.io`).

## Option 1 — Instant 1-Tap Install on Android (Recommended, No Build Needed)
1. Open **`https://paltro-sd01.github.io`** in Chrome on your Android phone (or scan the QR code in the dashboard's **Android App** tab).
2. Tap **"Install Android App"** in the top bar (or Chrome menu `⋮` -> **Add to Home screen / Install app**).
3. Android compiles and installs a standalone full-screen WebAPK with auto-fit screen resolution, bottom navigation bar, and offline telemetry cache.

## Option 2 — Build Standalone `.apk` with Android Studio or Gradle
1. Extract this folder and open it in **Android Studio**, or run:
   ```bash
   gradle assembleDebug
   ```
2. The installable APK is output to:
   `app/build/outputs/apk/debug/app-debug.apk`
