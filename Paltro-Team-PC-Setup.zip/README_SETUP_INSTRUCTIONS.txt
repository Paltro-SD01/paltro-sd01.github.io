====================================================================
PALTRO-SD01 | NEW TEAM PC SETUP INSTRUCTIONS (5-6 ENGINEER TEAM)
====================================================================

Why is this packaged as a .ZIP / .TXT / .PY?
Windows Chrome & Edge block direct downloads of raw .ps1 scripts with
"Couldn't download - Virus scan failed". Using any of the 3 methods
below bypasses that browser restriction completely!

--------------------------------------------------------------------
METHOD 1 (FASTEST - NO DOWNLOAD REQUIRED):
Open PowerShell on the new PC and paste this 1-line command:
--------------------------------------------------------------------
irm https://paltro-sd01.github.io/paltro_team_setup.txt | iex

--------------------------------------------------------------------
METHOD 2 (PYTHON SCRIPT - INCLUDED IN THIS ZIP):
Extract this ZIP and run:
--------------------------------------------------------------------
python paltro_team_setup.py

--------------------------------------------------------------------
METHOD 3 (POWERSHELL SCRIPT - INCLUDED IN THIS ZIP):
Extract this ZIP, open PowerShell in the folder, and run:
--------------------------------------------------------------------
powershell -ExecutionPolicy Bypass -File .\paltro_team_setup.ps1
